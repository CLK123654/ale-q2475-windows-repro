# 支付查询入口双栈发布说明

当前记录只针对rendered/payment-discovery.yaml中的本地清单，不代表集群已经接受变更。

现场管理员按results/apply-sequence.csv应用清单后，需要确认Service实际状态、EndpointSlice已接收，并核查双栈解析与连通性。
